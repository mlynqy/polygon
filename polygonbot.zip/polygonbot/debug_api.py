#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
API调试脚本 - 诊断PolygonScan API问题
"""

import requests
import json
from config import POLYGON_CONFIG

def test_api_key():
    """测试API密钥"""
    print("🔑 测试API密钥有效性...")
    
    # 测试基本API调用
    url = f"{POLYGON_CONFIG['ScanHost']}/api"
    params = {
        'module': 'stats',
        'action': 'ethsupply',
        'apikey': POLYGON_CONFIG['ApiKey']
    }
    
    try:
        response = requests.get(url, params=params, timeout=10)
        print(f"状态码: {response.status_code}")
        print(f"响应: {response.text}")
        
        if response.status_code == 200:
            data = response.json()
            print(f"解析后数据: {json.dumps(data, indent=2)}")
            
            if data.get('status') == '1':
                print("✅ API密钥有效")
                return True
            else:
                print(f"❌ API返回错误: {data.get('message')}")
                print(f"错误详情: {data.get('result', 'N/A')}")
        else:
            print(f"❌ HTTP错误: {response.status_code}")
            
    except Exception as e:
        print(f"❌ 请求异常: {e}")
    
    return False

def test_token_transactions():
    """测试代币交易查询"""
    print("\n🔍 测试代币交易查询...")
    
    # 使用一个已知的活跃地址进行测试
    test_address = "0x1a9C8182C09F50C8318d769245beA52c32BE35BC"  # Polygon Bridge地址
    usdt_contract = "0xc2132D05D31c914a87C6611C10748AEb04B58e8F"  # USDT合约
    
    url = f"{POLYGON_CONFIG['ScanHost']}/api"
    params = {
        'module': 'account',
        'action': 'tokentx',
        'contractaddress': usdt_contract,
        'address': test_address,
        'page': 1,
        'offset': 5,
        'startblock': 0,
        'endblock': 99999999,
        'sort': 'desc',
        'apikey': POLYGON_CONFIG['ApiKey']
    }
    
    try:
        response = requests.get(url, params=params, timeout=10)
        print(f"状态码: {response.status_code}")
        print(f"请求URL: {response.url}")
        
        if response.status_code == 200:
            data = response.json()
            print(f"响应状态: {data.get('status')}")
            print(f"响应消息: {data.get('message')}")
            
            if data.get('status') == '1':
                transactions = data.get('result', [])
                print(f"✅ 找到 {len(transactions)} 笔交易")
                if transactions:
                    print("最新交易示例:")
                    tx = transactions[0]
                    print(f"  哈希: {tx.get('hash')}")
                    print(f"  金额: {tx.get('value')}")
                    print(f"  代币: {tx.get('tokenSymbol')}")
                return True
            else:
                print(f"❌ API返回错误: {data.get('message')}")
                print(f"错误详情: {data.get('result', 'N/A')}")
        else:
            print(f"❌ HTTP错误: {response.status_code}")
            print(f"响应内容: {response.text}")
            
    except Exception as e:
        print(f"❌ 请求异常: {e}")
    
    return False

def test_normal_transactions():
    """测试普通交易查询"""
    print("\n🔍 测试普通交易查询...")
    
    # 使用一个已知的活跃地址进行测试
    test_address = "0x1a9C8182C09F50C8318d769245beA52c32BE35BC"  # Polygon Bridge地址
    
    url = f"{POLYGON_CONFIG['ScanHost']}/api"
    params = {
        'module': 'account',
        'action': 'txlist',
        'address': test_address,
        'page': 1,
        'offset': 5,
        'startblock': 0,
        'endblock': 99999999,
        'sort': 'desc',
        'apikey': POLYGON_CONFIG['ApiKey']
    }
    
    try:
        response = requests.get(url, params=params, timeout=10)
        print(f"状态码: {response.status_code}")
        print(f"请求URL: {response.url}")
        
        if response.status_code == 200:
            data = response.json()
            print(f"响应状态: {data.get('status')}")
            print(f"响应消息: {data.get('message')}")
            
            if data.get('status') == '1':
                transactions = data.get('result', [])
                print(f"✅ 找到 {len(transactions)} 笔交易")
                if transactions:
                    print("最新交易示例:")
                    tx = transactions[0]
                    print(f"  哈希: {tx.get('hash')}")
                    print(f"  金额: {tx.get('value')}")
                    print(f"  Gas: {tx.get('gas')}")
                return True
            else:
                print(f"❌ API返回错误: {data.get('message')}")
                print(f"错误详情: {data.get('result', 'N/A')}")
        else:
            print(f"❌ HTTP错误: {response.status_code}")
            print(f"响应内容: {response.text}")
            
    except Exception as e:
        print(f"❌ 请求异常: {e}")
    
    return False

def check_api_limits():
    """检查API限制"""
    print("\n📊 检查API限制...")
    
    url = f"{POLYGON_CONFIG['ScanHost']}/api"
    params = {
        'module': 'stats',
        'action': 'ethprice',
        'apikey': POLYGON_CONFIG['ApiKey']
    }
    
    try:
        response = requests.get(url, params=params, timeout=10)
        
        # 检查响应头中的限制信息
        headers = response.headers
        print("响应头信息:")
        for key, value in headers.items():
            if 'rate' in key.lower() or 'limit' in key.lower():
                print(f"  {key}: {value}")
        
        if response.status_code == 200:
            data = response.json()
            if data.get('status') == '1':
                print("✅ API调用成功")
            else:
                print(f"❌ API错误: {data.get('message')}")
                
    except Exception as e:
        print(f"❌ 检查失败: {e}")

def main():
    """主函数"""
    print("🔧 PolygonScan API 调试工具")
    print("=" * 50)
    print(f"API Host: {POLYGON_CONFIG['ScanHost']}")
    print(f"API Key: {POLYGON_CONFIG['ApiKey'][:10]}...")
    print("=" * 50)
    
    # 测试API密钥
    api_key_ok = test_api_key()
    
    if api_key_ok:
        # 测试代币交易
        test_token_transactions()
        
        # 测试普通交易
        test_normal_transactions()
        
        # 检查API限制
        check_api_limits()
    else:
        print("\n❌ API密钥测试失败，跳过其他测试")
        print("\n💡 可能的解决方案:")
        print("1. 检查API密钥是否正确")
        print("2. 确认API密钥是否已激活")
        print("3. 检查网络连接")
        print("4. 尝试使用免费API密钥或注册新的API密钥")
    
    print("\n" + "=" * 50)

if __name__ == "__main__":
    main()