# PolygonScan API密钥获取指南

## 问题说明

您遇到的 `API返回错误: NOTOK` 错误是因为使用了无效的API密钥。PolygonScan API需要有效的API密钥才能正常工作。

## 解决方案

### 方法1：获取免费API密钥（推荐）

1. **访问PolygonScan官网**
   - 打开 https://polygonscan.com/
   - 点击右上角的 "Sign In" 或 "Register"

2. **注册账户**
   - 如果没有账户，点击 "Click to sign up"
   - 填写用户名、邮箱和密码
   - 验证邮箱

3. **创建API密钥**
   - 登录后，点击用户名下拉菜单
   - 选择 "API Keys"
   - 点击 "Add" 按钮
   - 输入应用名称（如："Polygon Monitor Bot"）
   - 点击 "Create" 创建API密钥

4. **复制API密钥**
   - 复制生成的API密钥
   - 妥善保存，不要泄露给他人

### 方法2：使用现有的有效API密钥

如果您已经有PolygonScan的API密钥，请确保：
- API密钥格式正确（通常是32位字符串）
- API密钥未过期
- API密钥有足够的调用次数

## 配置API密钥

### 步骤1：更新.env文件

打开项目目录下的 `.env` 文件，将您的API密钥替换到相应位置：

```env
# Telegram Bot配置
TELEGRAM_BOT_TOKEN=your_telegram_bot_token_here

# PolygonScan API配置
POLYGON_API_KEY=YOUR_ACTUAL_API_KEY_HERE

# 数据库配置
DATABASE_PATH=polygon.db

# 监控配置
MONITOR_INTERVAL=3

# 日志配置
LOG_LEVEL=INFO
```

### 步骤2：测试API密钥

运行测试脚本验证API密钥是否有效：

```bash
python debug_api.py
```

如果看到 `✅ API密钥有效`，说明配置成功。

### 步骤3：重新启动机器人

```bash
python run.py
```

## API使用限制

### 免费账户限制
- 每秒最多5次请求
- 每天最多100,000次请求
- 对于大多数个人使用场景已经足够

### 付费账户
- 如需更高的请求限制，可以考虑升级到付费计划
- 访问 https://polygonscan.com/apis 了解详情

## 常见问题

### Q: API密钥格式是什么样的？
A: PolygonScan API密钥通常是32位的字母数字组合，例如：`ABC123DEF456GHI789JKL012MNO345PQ`

### Q: 为什么我的API密钥无效？
A: 可能的原因：
- API密钥输入错误（多了空格或少了字符）
- API密钥已过期
- 账户被暂停
- 超出了API调用限制

### Q: 可以使用别人的API密钥吗？
A: 不建议，因为：
- 违反服务条款
- 可能导致账户被封
- 无法控制使用量
- 存在安全风险

### Q: 如何监控API使用情况？
A: 在PolygonScan账户的API Keys页面可以查看：
- 今日使用次数
- 剩余调用次数
- 使用历史

## 安全建议

1. **不要公开API密钥**
   - 不要将API密钥提交到公共代码仓库
   - 不要在聊天或论坛中分享

2. **定期更换API密钥**
   - 建议每3-6个月更换一次
   - 如果怀疑泄露，立即更换

3. **监控使用情况**
   - 定期检查API使用统计
   - 发现异常使用立即调查

## 联系支持

如果遇到问题，可以：
- 查看PolygonScan官方文档：https://docs.polygonscan.com/
- 联系PolygonScan支持团队
- 在项目GitHub页面提交Issue

---

**注意**：获取API密钥后，请务必重新运行 `python debug_api.py` 确认配置正确，然后再启动机器人。