#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import requests
import sqlite3
from config import POLYGON_CONFIG
from datetime import datetime

def check_address_transactions():
    """检查绑定地址的交易情况"""
    print("=" * 60)
    print("🔍 检查绑定地址的交易情况")
    print("=" * 60)
    
    # 获取绑定的地址
    conn = sqlite3.connect('polygon.db')
    cursor = conn.cursor()
    cursor.execute('SELECT DISTINCT address FROM user_addresses')
    addresses = [row[0] for row in cursor.fetchall()]
    conn.close()
    
    print(f"📍 找到 {len(addresses)} 个绑定地址")
    print()
    
    for i, address in enumerate(addresses, 1):
        print(f"🔍 检查地址 {i}: {address}")
        print("-" * 50)
        
        # 检查普通交易
        check_normal_transactions(address)
        
        # 检查代币交易
        check_token_transactions(address)
        
        print()

def check_normal_transactions(address):
    """检查普通交易"""
    try:
        url = f"{POLYGON_CONFIG['ScanHost']}/api"
        params = {
            'module': 'account',
            'action': 'txlist',
            'address': address,
            'page': 1,
            'offset': 5,  # 只获取最近5笔
            'startblock': 0,
            'endblock': 99999999,
            'sort': 'desc',
            'apikey': POLYGON_CONFIG['ApiKey']
        }
        
        response = requests.get(url, params=params, timeout=10)
        data = response.json()
        
        if data['status'] == '1':
            transactions = data['result']
            print(f"💰 POL交易: 找到 {len(transactions)} 笔")
            
            for tx in transactions[:3]:  # 显示最近3笔
                timestamp = int(tx['timeStamp'])
                tx_time = datetime.fromtimestamp(timestamp)
                value_pol = int(tx['value']) / 10**18
                
                print(f"  📅 {tx_time.strftime('%Y-%m-%d %H:%M:%S')}")
                print(f"  💸 {tx['from']} → {tx['to']}")
                print(f"  💰 {value_pol:.6f} POL")
                print(f"  🔗 {tx['hash'][:20]}...")
                print()
        else:
            print(f"💰 POL交易: {data.get('message', 'No transactions found')}")
            
    except Exception as e:
        print(f"❌ 检查POL交易失败: {e}")

def check_token_transactions(address):
    """检查代币交易"""
    try:
        # 检查USDT交易
        usdt_contract = "0xc2132D05D31c914a87C6611C10748AEb04B58e8F"
        
        url = f"{POLYGON_CONFIG['ScanHost']}/api"
        params = {
            'module': 'account',
            'action': 'tokentx',
            'contractaddress': usdt_contract,
            'address': address,
            'page': 1,
            'offset': 5,
            'startblock': 0,
            'endblock': 99999999,
            'sort': 'desc',
            'apikey': POLYGON_CONFIG['ApiKey']
        }
        
        response = requests.get(url, params=params, timeout=10)
        data = response.json()
        
        if data['status'] == '1':
            transactions = data['result']
            print(f"🪙 USDT交易: 找到 {len(transactions)} 笔")
            
            for tx in transactions[:3]:  # 显示最近3笔
                timestamp = int(tx['timeStamp'])
                tx_time = datetime.fromtimestamp(timestamp)
                value_usdt = int(tx['value']) / 10**int(tx['tokenDecimal'])
                
                print(f"  📅 {tx_time.strftime('%Y-%m-%d %H:%M:%S')}")
                print(f"  💸 {tx['from']} → {tx['to']}")
                print(f"  💰 {value_usdt:.6f} USDT")
                print(f"  🔗 {tx['hash'][:20]}...")
                print()
        else:
            print(f"🪙 USDT交易: {data.get('message', 'No transactions found')}")
            
    except Exception as e:
        print(f"❌ 检查USDT交易失败: {e}")

if __name__ == "__main__":
    check_address_transactions()