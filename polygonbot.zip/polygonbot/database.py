#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
数据库管理模块 - Polygon交易监控机器人
"""

import sqlite3
import logging
from datetime import datetime
from config import DATABASE_PATH

logger = logging.getLogger(__name__)

class DatabaseManager:
    """数据库管理器"""
    
    def __init__(self, db_path=None):
        self.db_path = db_path or DATABASE_PATH
    
    def get_connection(self):
        """获取数据库连接"""
        return sqlite3.connect(self.db_path)
    
    def init_database(self):
        """初始化数据库"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            # 创建用户表
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS users (
                    chat_id INTEGER PRIMARY KEY,
                    username TEXT,
                    first_name TEXT,
                    last_name TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # 创建用户地址绑定表
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS user_addresses (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    chat_id INTEGER NOT NULL,
                    address TEXT NOT NULL,
                    remark TEXT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(chat_id, address),
                    FOREIGN KEY (chat_id) REFERENCES users (chat_id)
                )
            ''')
            
            # 创建交易记录表（防止重复通知）
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS processed_transactions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    tx_hash TEXT UNIQUE NOT NULL,
                    block_number INTEGER,
                    from_address TEXT,
                    to_address TEXT,
                    token_address TEXT,
                    amount TEXT,
                    processed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # 创建监控统计表
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS monitor_stats (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    date TEXT UNIQUE NOT NULL,
                    transactions_processed INTEGER DEFAULT 0,
                    notifications_sent INTEGER DEFAULT 0,
                    api_requests INTEGER DEFAULT 0,
                    errors INTEGER DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # 创建索引
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_user_addresses_chat_id ON user_addresses(chat_id)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_user_addresses_address ON user_addresses(address)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_processed_transactions_hash ON processed_transactions(tx_hash)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_processed_transactions_block ON processed_transactions(block_number)')
            
            conn.commit()
            logger.info("数据库初始化完成")
            
        except Exception as e:
            logger.error(f"数据库初始化失败: {e}")
            conn.rollback()
            raise
        finally:
            conn.close()
    
    def add_user(self, chat_id, username=None, first_name=None, last_name=None):
        """添加或更新用户"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                INSERT OR REPLACE INTO users (chat_id, username, first_name, last_name, updated_at)
                VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
            ''', (chat_id, username, first_name, last_name))
            
            conn.commit()
            logger.info(f"用户 {chat_id} 信息已更新")
            
        except Exception as e:
            logger.error(f"添加用户失败: {e}")
            conn.rollback()
            raise
        finally:
            conn.close()
    
    def bind_address(self, chat_id, address, remark):
        """绑定地址"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                INSERT INTO user_addresses (chat_id, address, remark)
                VALUES (?, ?, ?)
            ''', (chat_id, address.lower(), remark))
            
            conn.commit()
            logger.info(f"地址绑定成功: {address} -> {chat_id}")
            return True
            
        except sqlite3.IntegrityError:
            logger.warning(f"地址已存在: {address} -> {chat_id}")
            return False
        except Exception as e:
            logger.error(f"绑定地址失败: {e}")
            conn.rollback()
            raise
        finally:
            conn.close()
    
    def unbind_address(self, chat_id, address):
        """解绑地址"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                DELETE FROM user_addresses 
                WHERE chat_id = ? AND address = ?
            ''', (chat_id, address.lower()))
            
            success = cursor.rowcount > 0
            conn.commit()
            
            if success:
                logger.info(f"地址解绑成功: {address} -> {chat_id}")
            else:
                logger.warning(f"地址不存在: {address} -> {chat_id}")
            
            return success
            
        except Exception as e:
            logger.error(f"解绑地址失败: {e}")
            conn.rollback()
            raise
        finally:
            conn.close()
    
    def get_user_addresses(self, chat_id):
        """获取用户绑定的地址"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                SELECT address, remark, created_at 
                FROM user_addresses 
                WHERE chat_id = ?
                ORDER BY created_at DESC
            ''', (chat_id,))
            
            return cursor.fetchall()
            
        except Exception as e:
            logger.error(f"获取用户地址失败: {e}")
            raise
        finally:
            conn.close()
    
    def get_all_monitored_addresses(self):
        """获取所有监控地址"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('SELECT DISTINCT address FROM user_addresses')
            return [row[0] for row in cursor.fetchall()]
            
        except Exception as e:
            logger.error(f"获取监控地址失败: {e}")
            raise
        finally:
            conn.close()
    
    def get_address_subscribers(self, address):
        """获取地址的订阅者"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                SELECT chat_id, remark 
                FROM user_addresses 
                WHERE address = ?
            ''', (address.lower(),))
            
            return cursor.fetchall()
            
        except Exception as e:
            logger.error(f"获取地址订阅者失败: {e}")
            raise
        finally:
            conn.close()
    
    def is_transaction_processed(self, tx_hash):
        """检查交易是否已处理"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('SELECT 1 FROM processed_transactions WHERE tx_hash = ?', (tx_hash,))
            return cursor.fetchone() is not None
            
        except Exception as e:
            logger.error(f"检查交易状态失败: {e}")
            raise
        finally:
            conn.close()
    
    def mark_transaction_processed(self, tx_hash, block_number=None, from_address=None, to_address=None, token_address=None, amount=None):
        """标记交易为已处理"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                INSERT OR IGNORE INTO processed_transactions 
                (tx_hash, block_number, from_address, to_address, token_address, amount)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (tx_hash, block_number, from_address, to_address, token_address, amount))
            
            conn.commit()
            
        except Exception as e:
            logger.error(f"标记交易失败: {e}")
            conn.rollback()
            raise
        finally:
            conn.close()
    
    def update_stats(self, transactions_processed=0, notifications_sent=0, api_requests=0, errors=0):
        """更新统计信息"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            today = datetime.now().strftime('%Y-%m-%d')
            
            cursor.execute('''
                INSERT OR REPLACE INTO monitor_stats 
                (date, transactions_processed, notifications_sent, api_requests, errors)
                VALUES (
                    ?, 
                    COALESCE((SELECT transactions_processed FROM monitor_stats WHERE date = ?), 0) + ?,
                    COALESCE((SELECT notifications_sent FROM monitor_stats WHERE date = ?), 0) + ?,
                    COALESCE((SELECT api_requests FROM monitor_stats WHERE date = ?), 0) + ?,
                    COALESCE((SELECT errors FROM monitor_stats WHERE date = ?), 0) + ?
                )
            ''', (today, today, transactions_processed, today, notifications_sent, today, api_requests, today, errors))
            
            conn.commit()
            
        except Exception as e:
            logger.error(f"更新统计信息失败: {e}")
            conn.rollback()
        finally:
            conn.close()
    
    def get_stats(self, days=7):
        """获取统计信息"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                SELECT date, transactions_processed, notifications_sent, api_requests, errors
                FROM monitor_stats 
                ORDER BY date DESC 
                LIMIT ?
            ''', (days,))
            
            return cursor.fetchall()
            
        except Exception as e:
            logger.error(f"获取统计信息失败: {e}")
            raise
        finally:
            conn.close()
    
    def cleanup_old_transactions(self, days=30):
        """清理旧的交易记录"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                DELETE FROM processed_transactions 
                WHERE processed_at < datetime('now', '-{} days')
            '''.format(days))
            
            deleted_count = cursor.rowcount
            conn.commit()
            
            logger.info(f"清理了 {deleted_count} 条旧交易记录")
            return deleted_count
            
        except Exception as e:
            logger.error(f"清理旧交易记录失败: {e}")
            conn.rollback()
            raise
        finally:
            conn.close()

# 全局数据库管理器实例
db_manager = DatabaseManager()

def init_database():
    """初始化数据库（兼容性函数）"""
    db_manager.init_database()

if __name__ == "__main__":
    # 测试数据库功能
    print("初始化数据库...")
    init_database()
    print("数据库初始化完成")