#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
配置测试脚本 - Polygon交易监控机器人
"""

import sys
from pathlib import Path

# 添加当前目录到Python路径
sys.path.insert(0, str(Path(__file__).parent))

try:
    from config import (
        TELEGRAM_BOT_TOKEN, POLYGON_API_KEY, POLYGON_CONFIG,
        DATABASE_PATH, MONITOR_INTERVAL, validate_config
    )
    from database import db_manager
except ImportError as e:
    print(f"❌ 导入模块失败: {e}")
    sys.exit(1)

def test_config():
    """测试配置"""
    print("🔧 配置测试")
    print("=" * 50)
    
    # 检查环境变量
    print("\n📋 环境变量检查:")
    print(f"  TELEGRAM_BOT_TOKEN: {'✅ 已配置' if TELEGRAM_BOT_TOKEN else '❌ 未配置'}")
    print(f"  POLYGON_API_KEY: {'✅ 已配置' if POLYGON_API_KEY else '❌ 未配置'}")
    print(f"  DATABASE_PATH: {DATABASE_PATH}")
    print(f"  MONITOR_INTERVAL: {MONITOR_INTERVAL}秒")
    
    # 检查Polygon配置
    print("\n🔗 Polygon配置检查:")
    print(f"  ScanHost: {POLYGON_CONFIG['ScanHost']}")
    print(f"  ChainId: {POLYGON_CONFIG['ChainId']}")
    print(f"  ApiKey: {POLYGON_CONFIG['ApiKey'][:10]}...")
    print(f"  支持代币数量: {len(POLYGON_CONFIG['ERC20'])}")
    
    for token in POLYGON_CONFIG['ERC20']:
        print(f"    - {token['Name']}: {token['ContractAddress']}")
    
    # 验证配置
    print("\n✅ 配置验证:")
    try:
        validate_config()
        print("  ✅ 配置验证通过")
    except Exception as e:
        print(f"  ❌ 配置验证失败: {e}")
        return False
    
    return True

def test_database():
    """测试数据库"""
    print("\n📊 数据库测试")
    print("=" * 50)
    
    try:
        # 初始化数据库
        print("\n🔧 初始化数据库...")
        db_manager.init_database()
        print("  ✅ 数据库初始化成功")
        
        # 测试数据库操作
        print("\n🧪 测试数据库操作...")
        
        # 测试用户添加
        test_chat_id = 123456789
        db_manager.add_user(test_chat_id, "test_user", "Test", "User")
        print("  ✅ 用户添加测试通过")
        
        # 测试地址绑定
        test_address = "0x1234567890123456789012345678901234567890"
        success = db_manager.bind_address(test_chat_id, test_address, "测试地址")
        if success:
            print("  ✅ 地址绑定测试通过")
        else:
            print("  ❌ 地址绑定测试失败")
        
        # 测试地址查询
        addresses = db_manager.get_user_addresses(test_chat_id)
        if addresses:
            print(f"  ✅ 地址查询测试通过，找到 {len(addresses)} 个地址")
        else:
            print("  ❌ 地址查询测试失败")
        
        # 测试地址解绑
        success = db_manager.unbind_address(test_chat_id, test_address)
        if success:
            print("  ✅ 地址解绑测试通过")
        else:
            print("  ❌ 地址解绑测试失败")
        
        # 测试交易处理
        test_tx_hash = "0xtest123456789"
        db_manager.mark_transaction_processed(test_tx_hash)
        is_processed = db_manager.is_transaction_processed(test_tx_hash)
        if is_processed:
            print("  ✅ 交易处理测试通过")
        else:
            print("  ❌ 交易处理测试失败")
        
        return True
        
    except Exception as e:
        print(f"  ❌ 数据库测试失败: {e}")
        return False

def test_api():
    """测试API连接"""
    print("\n🌐 API连接测试")
    print("=" * 50)
    
    try:
        import requests
        
        # 测试PolygonScan API
        print("\n🔗 测试PolygonScan API...")
        api_url = f"{POLYGON_CONFIG['ScanHost']}/api"
        params = {
            'module': 'stats',
            'action': 'ethsupply',
            'apikey': POLYGON_CONFIG['ApiKey']
        }
        
        response = requests.get(api_url, params=params, timeout=10)
        if response.status_code == 200:
            data = response.json()
            if data.get('status') == '1':
                print("  ✅ PolygonScan API连接成功")
                return True
            else:
                print(f"  ❌ API返回错误: {data.get('message', '未知错误')}")
        else:
            print(f"  ❌ API请求失败，状态码: {response.status_code}")
        
    except Exception as e:
        print(f"  ❌ API测试失败: {e}")
    
    return False

def main():
    """主函数"""
    print("🧪 Polygon交易监控机器人 - 配置测试")
    print("=" * 60)
    
    # 测试配置
    config_ok = test_config()
    
    # 测试数据库
    db_ok = test_database()
    
    # 测试API
    api_ok = test_api()
    
    # 总结
    print("\n📊 测试总结")
    print("=" * 50)
    print(f"配置测试: {'✅ 通过' if config_ok else '❌ 失败'}")
    print(f"数据库测试: {'✅ 通过' if db_ok else '❌ 失败'}")
    print(f"API测试: {'✅ 通过' if api_ok else '❌ 失败'}")
    
    if config_ok and db_ok:
        print("\n🎉 基础功能测试通过！")
        if not api_ok:
            print("⚠️  API测试失败，请检查网络连接和API密钥")
        print("\n📝 下一步:")
        print("1. 在.env文件中配置正确的TELEGRAM_BOT_TOKEN")
        print("2. 运行 python run.py 启动机器人")
    else:
        print("\n❌ 测试失败，请检查配置")
    
    print("\n" + "=" * 60)

if __name__ == "__main__":
    main()