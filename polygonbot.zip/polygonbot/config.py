#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
配置文件 - Polygon交易监控机器人
"""

import os
from dotenv import load_dotenv

# 加载环境变量
load_dotenv()

# Telegram配置
TELEGRAM_BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN')

# Polygon API配置
POLYGON_API_KEY = os.getenv('POLYGON_API_KEY', 'YourApiKeyToken')

# Polygon网络配置
POLYGON_CONFIG = {
    "ScanHost": "https://api.polygonscan.com",
    "ChainId": 137,
    "ApiKey": POLYGON_API_KEY,
    "ERC20Name": "ERC20",
    "ERC20": [
        {
            "Name": "POL",
            "ContractAddress": "0x0000000000000000000000000000000000001010",  # POL代币合约地址(Polygon原生代币)
            "Decimals": 18
        },
        {
            "Name": "USDT",
            "ContractAddress": "0xc2132D05D31c914a87C6611C10748AEb04B58e8F",
            "Decimals": 6
        },
        {
            "Name": "USDC",
            "ContractAddress": "0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359",
            "Decimals": 6
        }
    ]
}

# 数据库配置
DATABASE_PATH = os.getenv('DATABASE_PATH', 'polygon.db')

# 监控配置
MONITOR_INTERVAL = int(os.getenv('MONITOR_INTERVAL', 3))  # 监控间隔（秒）
MAX_TRANSACTIONS_PER_REQUEST = 10  # 每次请求的最大交易数
API_REQUEST_TIMEOUT = 10  # API请求超时时间（秒）

# 日志配置
LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
LOG_FORMAT = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'

# 消息格式配置
MESSAGE_TEMPLATES = {
    'welcome': (
        "🤖 欢迎使用Polygon交易监控机器人！\n\n"
        "📋 可用命令：\n"
        "/bind <地址> <备注> - 绑定监控地址\n"
        "/unbind <地址> - 解绑地址\n"
        "/list - 查看已绑定的地址\n\n"
        "💰 监控代币：POL, USDT, USDC\n"
        "⏰ 检测间隔：{interval}秒\n"
        "🔔 实时通知新交易"
    ),
    'transaction': (
        "🔔 新交易！{amount} {token}\n\n"
        "交易类型：#{tx_type}\n\n"
        "交易币种：#{token}\n\n"
        "交易金额：{amount} {token}\n\n"
        "出账地址：{from_addr}{from_remark}\n\n"
        "入账地址：{to_addr}{to_remark}\n\n"
        "交易时间：{time}\n\n"
        "交易哈希：{hash}"
    ),
    'bind_success': "✅ 地址绑定成功！\n地址：{address}\n备注：{remark}",
    'bind_error_format': "❌ 格式错误！请使用：/bind <地址> <备注>",
    'bind_error_address': "❌ 地址格式错误！请输入有效的以太坊地址",
    'bind_error_exists': "❌ 该地址已经绑定过了！",
    'unbind_success': "✅ 地址解绑成功！\n地址：{address}",
    'unbind_error_format': "❌ 格式错误！请使用：/unbind <地址>",
    'unbind_error_notfound': "❌ 未找到该地址！",
    'list_empty': "📭 您还没有绑定任何地址",
    'list_header': "📋 您绑定的地址列表：\n\n"
}

# API端点配置
API_ENDPOINTS = {
    'token_transactions': '/api?module=account&action=tokentx',
    'normal_transactions': '/api?module=account&action=txlist',
    'token_info': '/api?module=token&action=tokeninfo'
}

# 验证配置
def validate_config():
    """验证配置是否正确"""
    errors = []
    
    if not TELEGRAM_BOT_TOKEN:
        errors.append("TELEGRAM_BOT_TOKEN未设置")
    
    if not POLYGON_CONFIG['ApiKey']:
        errors.append("POLYGON_API_KEY未设置")
    
    if MONITOR_INTERVAL < 1:
        errors.append("MONITOR_INTERVAL必须大于0")
    
    return errors

# 获取代币信息
def get_token_by_address(contract_address):
    """根据合约地址获取代币信息"""
    for token in POLYGON_CONFIG["ERC20"]:
        if token["ContractAddress"].lower() == contract_address.lower():
            return token
    return None

# 获取代币信息
def get_token_by_name(token_name):
    """根据代币名称获取代币信息"""
    for token in POLYGON_CONFIG["ERC20"]:
        if token["Name"].upper() == token_name.upper():
            return token
    return None