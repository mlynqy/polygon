#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sqlite3
from database import db_manager

def check_database():
    """检查数据库中的数据"""
    print("=" * 50)
    print("📊 数据库状态检查")
    print("=" * 50)
    
    try:
        # 检查用户表
        conn = sqlite3.connect('polygon.db')
        cursor = conn.cursor()
        
        # 检查用户
        cursor.execute('SELECT * FROM users')
        users = cursor.fetchall()
        print(f"👥 注册用户数量: {len(users)}")
        for user in users:
            print(f"  用户ID: {user[1]}, 用户名: {user[2]}, 注册时间: {user[3]}")
        
        print()
        
        # 检查绑定地址
        cursor.execute('SELECT * FROM user_addresses')
        addresses = cursor.fetchall()
        print(f"📍 绑定地址数量: {len(addresses)}")
        for addr in addresses:
            print(f"  用户ID: {addr[1]}, 地址: {addr[2]}, 备注: {addr[3]}, 绑定时间: {addr[4]}")
        
        print()
        
        # 检查已处理交易
        cursor.execute('SELECT * FROM processed_transactions ORDER BY processed_at DESC LIMIT 10')
        transactions = cursor.fetchall()
        print(f"📝 已处理交易数量: {len(transactions)} (显示最近10条)")
        for tx in transactions:
            print(f"  交易哈希: {tx[1]}, 处理时间: {tx[2]}")
        
        conn.close()
        
    except Exception as e:
        print(f"❌ 检查数据库时出错: {e}")

if __name__ == "__main__":
    check_database()