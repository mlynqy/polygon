# Polygon交易监控机器人

一个基于Telegram的Polygon网络交易监控机器人，支持实时监控POL、USDT、USDC代币交易。

## 功能特性

- 🔔 实时监控Polygon网络交易（3秒检测间隔）
- 💰 支持监控代币：POL、USDT、USDC
- 📱 Telegram机器人交互界面
- 🗄️ SQLite数据库存储用户绑定信息
- ⏰ 北京时间显示交易时间
- 🚫 防重复通知机制
- 📝 自定义地址备注功能

## 监控代币信息

| 代币 | 合约地址 | 网络 |
|------|----------|------|
| POL | 0x455e53908abcb018c4b4d13c80c5e7c2a3e8a9c9 | Polygon |
| USDT | 0xc2132D05D31c914a87C6611C10748AEb04B58e8F | Polygon |
| USDC | 0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359 | Polygon |

## 安装和配置

### 1. 安装依赖

```bash
pip install -r requirements.txt
```

### 2. 配置环境变量

复制 `.env.example` 为 `.env` 并填入您的配置：

```bash
cp .env.example .env
```

编辑 `.env` 文件：

```env
# Telegram Bot Token (从 @BotFather 获取)
TELEGRAM_BOT_TOKEN=your_telegram_bot_token_here

# Polygon API密钥 (从 https://polygonscan.com/apis 获取)
POLYGON_API_KEY=BTQ8M7XBXBFESYURGQEQ37N1ZX4SRDSSQ1

# 其他配置
DATABASE_PATH=polygon.db
MONITOR_INTERVAL=3
LOG_LEVEL=INFO
```

### 3. 创建Telegram机器人

1. 在Telegram中找到 [@BotFather](https://t.me/BotFather)
2. 发送 `/newbot` 创建新机器人
3. 按提示设置机器人名称和用户名
4. 获取Bot Token并填入 `.env` 文件

### 4. 获取Polygon API密钥

1. 访问 [PolygonScan API](https://polygonscan.com/apis)
2. 注册账户并创建API密钥
3. 将API密钥填入 `.env` 文件

## 使用方法

### 启动机器人

**推荐方式（使用启动脚本）：**
```bash
python run.py
```

**直接启动：**
```bash
python polygon_monitor.py
```

**或使用简化启动脚本：**
```bash
python start.py
```

### Telegram命令

| 命令 | 说明 | 示例 |
|------|------|------|
| `/start` | 启动机器人，注册用户 | `/start` |
| `/bind <地址> <备注>` | 绑定监控地址 | `/bind 0x1234...abcd 我的钱包` |
| `/unbind <地址>` | 解绑地址 | `/unbind 0x1234...abcd` |
| `/list` | 查看已绑定的地址 | `/list` |

### 交易通知格式

```
🔔 新交易！100.50 USDT

交易类型：#入账

交易币种：#USDT

交易金额：100.50 USDT

出账地址：0x1234...abcd

入账地址：0x5678...efgh ← 我的钱包

交易时间：2025-01-21 20:09:57

交易哈希：0xabcd1234...
```

## 项目结构

```
polygon/
├── polygon_monitor.py    # 主监控程序
├── config.py            # 配置管理
├── database.py          # 数据库管理
├── run.py              # 推荐启动脚本
├── start.py            # 简化启动脚本
├── requirements.txt     # 依赖包列表
├── .env.example        # 环境变量模板
├── .env                # 环境变量配置（需要创建）
├── README.md           # 项目文档
└── polygon.db          # SQLite数据库（自动创建）
```

## 技术架构

### 核心组件

- **PolygonMonitor**: 主要的监控类，负责处理Telegram命令和交易监控
- **DatabaseManager**: 数据库管理器，处理所有数据库操作
- **配置管理**: 集中管理所有配置参数和环境变量
- **API**: PolygonScan API，获取区块链交易数据
- **Telegram Bot**: 处理用户交互和发送通知

### 数据库结构

#### users表
```sql
CREATE TABLE users (
    chat_id INTEGER PRIMARY KEY,
    username TEXT,
    first_name TEXT,
    last_name TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### user_addresses表
```sql
CREATE TABLE user_addresses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER NOT NULL,
    address TEXT NOT NULL,
    remark TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(chat_id, address),
    FOREIGN KEY (chat_id) REFERENCES users (chat_id)
);
```

#### processed_transactions表
```sql
CREATE TABLE processed_transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tx_hash TEXT UNIQUE NOT NULL,
    block_number INTEGER,
    from_address TEXT,
    to_address TEXT,
    token_address TEXT,
    amount TEXT,
    processed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### monitor_stats表
```sql
CREATE TABLE monitor_stats (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT UNIQUE NOT NULL,
    transactions_processed INTEGER DEFAULT 0,
    notifications_sent INTEGER DEFAULT 0,
    api_requests INTEGER DEFAULT 0,
    errors INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## 配置说明

### Polygon网络配置

```python
CONFIG = {
    "ScanHost": "https://api.polygonscan.com",
    "ChainId": 137,
    "ApiKey": "BTQ8M7XBXBFESYURGQEQ37N1ZX4SRDSSQ1",
    "ERC20Name": "ERC20",
    "ERC20": [
        {
            "Name": "POL",
            "ContractAddress": "0x455e53908abcb018c4b4d13c80c5e7c2a3e8a9c9"
        },
        {
            "Name": "USDT",
            "ContractAddress": "0xc2132D05D31c914a87C6611C10748AEb04B58e8F"
        },
        {
            "Name": "USDC",
            "ContractAddress": "0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359"
        }
    ]
}
```

## 监控机制

1. **实时检测**: 每3秒检查一次新交易
2. **防重复**: 使用交易哈希防止重复通知
3. **时间过滤**: 只通知机器人启动后的新交易
4. **多代币支持**: 同时监控POL、USDT、USDC等代币
5. **智能备注**: 自动显示监控地址的备注信息

## 安全注意事项

- ✅ 不要将 `.env` 文件提交到版本控制
- ✅ 定期更换API密钥
- ✅ 保护好Telegram Bot Token
- ✅ 定期备份数据库文件

## 故障排除

### 常见问题

1. **API返回错误: NOTOK**
   - **原因**: API密钥无效或过期
   - **解决方案**: 参考 [API_KEY_GUIDE.md](API_KEY_GUIDE.md) 获取有效的PolygonScan API密钥
   - **测试**: 运行 `python debug_api.py` 验证API密钥

2. **机器人无响应**
   - 检查TELEGRAM_BOT_TOKEN是否正确
   - 确认机器人已通过BotFather创建
   - 检查网络连接

3. **无法获取交易**
   - 检查POLYGON_API_KEY是否有效
   - 确认API调用次数未超限
   - 检查地址格式是否正确

4. **数据库错误**
   - 检查数据库文件权限
   - 确认磁盘空间充足
   - 重新初始化数据库

5. **查看日志**
   ```bash
   tail -f polygon_monitor.log
   ```

### 调试工具

- **配置测试**: `python test_config.py`
- **API调试**: `python debug_api.py`
- **完整测试**: 运行上述两个脚本确保所有配置正确

### 日志查看

机器人运行时会输出详细日志，包括：
- 交易检测状态
- API请求结果
- 错误信息
- 用户操作记录

## 开发和扩展

### 添加新代币

在 `CONFIG["ERC20"]` 中添加新的代币配置：

```python
{
    "Name": "NEW_TOKEN",
    "ContractAddress": "0x..."
}
```

### 自定义通知格式

修改 `format_transaction_message` 方法来自定义通知消息格式。

### 扩展命令

添加新的命令处理器：

```python
self.application.add_handler(CommandHandler("new_command", self.new_command_handler))
```

## 许可证

MIT License

## 支持

如有问题或建议，请创建Issue或联系开发者。