#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
启动脚本 - Polygon交易监控机器人

使用方法:
1. 确保已安装依赖: pip install -r requirements.txt
2. 配置 .env 文件中的 TELEGRAM_BOT_TOKEN
3. 运行: python start.py
"""

import os
import sys
import logging
from dotenv import load_dotenv

def check_requirements():
    """检查运行环境"""
    print("🔍 检查运行环境...")
    
    # 检查Python版本
    if sys.version_info < (3, 8):
        print("❌ 错误: 需要Python 3.8或更高版本")
        return False
    
    # 检查必要的包
    required_packages = [
        'telegram',
        'requests', 
        'python-dotenv',
        'sqlite3'
    ]
    
    missing_packages = []
    for package in required_packages:
        try:
            if package == 'sqlite3':
                import sqlite3
            elif package == 'telegram':
                import telegram
            elif package == 'requests':
                import requests
            elif package == 'python-dotenv':
                import dotenv
        except ImportError:
            missing_packages.append(package)
    
    if missing_packages:
        print(f"❌ 缺少依赖包: {', '.join(missing_packages)}")
        print("请运行: pip install -r requirements.txt")
        return False
    
    print("✅ 运行环境检查通过")
    return True

def check_config():
    """检查配置文件"""
    print("🔍 检查配置文件...")
    
    # 检查.env文件
    if not os.path.exists('.env'):
        print("❌ 错误: 未找到.env文件")
        print("请复制.env.example为.env并填入配置")
        return False
    
    # 加载环境变量
    load_dotenv()
    
    # 检查必要的环境变量
    bot_token = os.getenv('TELEGRAM_BOT_TOKEN')
    if not bot_token or bot_token == 'your_telegram_bot_token_here':
        print("❌ 错误: 请在.env文件中设置有效的TELEGRAM_BOT_TOKEN")
        print("获取方法: 联系@BotFather创建机器人")
        return False
    
    api_key = os.getenv('POLYGON_API_KEY')
    if not api_key:
        print("⚠️  警告: 未设置POLYGON_API_KEY，将使用默认密钥")
    
    print("✅ 配置文件检查通过")
    return True

def main():
    """主函数"""
    print("🚀 启动Polygon交易监控机器人")
    print("=" * 50)
    
    # 检查运行环境
    if not check_requirements():
        sys.exit(1)
    
    # 检查配置
    if not check_config():
        sys.exit(1)
    
    print("\n🤖 正在启动机器人...")
    print("按 Ctrl+C 停止机器人")
    print("=" * 50)
    
    try:
        # 导入并运行监控器
        from polygon_monitor import PolygonMonitor
        import asyncio
        
        monitor = PolygonMonitor()
        asyncio.run(monitor.run())
        
    except KeyboardInterrupt:
        print("\n👋 机器人已停止")
    except Exception as e:
        print(f"\n❌ 启动失败: {e}")
        logging.exception("启动错误")
        sys.exit(1)

if __name__ == "__main__":
    main()