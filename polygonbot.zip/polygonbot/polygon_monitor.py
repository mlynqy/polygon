#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import asyncio
import logging
import requests
import time
from datetime import datetime, timezone, timedelta
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes
import os
from config import (
    TELEGRAM_BOT_TOKEN,
    POLYGON_CONFIG,
    DATABASE_PATH,
    MONITOR_INTERVAL,
    LOG_LEVEL,
    LOG_FORMAT,
    MESSAGE_TEMPLATES,
    API_REQUEST_TIMEOUT,
    MAX_TRANSACTIONS_PER_REQUEST,
    get_token_by_address,
    validate_config
)
from database import db_manager

# 配置日志
logging.basicConfig(
    format=LOG_FORMAT,
    level=getattr(logging, LOG_LEVEL.upper())
)
logger = logging.getLogger(__name__)

# 数据库初始化现在由 database.py 模块处理

class PolygonMonitor:
    def __init__(self):
        self.bot_token = TELEGRAM_BOT_TOKEN
        self.application = None
        self.monitoring = False
        # 移除启动时间限制，允许处理所有交易
        # self.start_time = int(time.time())
        
        # 验证配置
        config_errors = validate_config()
        if config_errors:
            for error in config_errors:
                logger.error(f"配置错误: {error}")
            raise ValueError("配置验证失败")
        
    async def start_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """处理/start命令"""
        chat_id = update.effective_chat.id
        user = update.effective_user
        
        # 保存用户信息到数据库
        db_manager.add_user(
            chat_id=chat_id,
            username=user.username,
            first_name=user.first_name,
            last_name=user.last_name
        )
        
        welcome_msg = MESSAGE_TEMPLATES['welcome'].format(interval=MONITOR_INTERVAL)
        await update.message.reply_text(welcome_msg)
    
    async def bind_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """处理/bind命令"""
        chat_id = update.effective_chat.id
        
        if len(context.args) < 2:
            await update.message.reply_text(MESSAGE_TEMPLATES['bind_error_format'])
            return
        
        address = context.args[0].lower()
        remark = ' '.join(context.args[1:])
        
        # 验证地址格式
        if not address.startswith('0x') or len(address) != 42:
            await update.message.reply_text(MESSAGE_TEMPLATES['bind_error_address'])
            return
        
        try:
            success = db_manager.bind_address(chat_id, address, remark)
            
            if success:
                success_msg = MESSAGE_TEMPLATES['bind_success'].format(address=address, remark=remark)
                await update.message.reply_text(success_msg)
            else:
                await update.message.reply_text(MESSAGE_TEMPLATES['bind_error_exists'])
                
        except Exception as e:
            logger.error(f"绑定地址时出错: {e}")
            await update.message.reply_text(MESSAGE_TEMPLATES['bind_error_exists'])
    
    async def unbind_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """处理/unbind命令"""
        chat_id = update.effective_chat.id
        
        if len(context.args) != 1:
            await update.message.reply_text(MESSAGE_TEMPLATES['unbind_error_format'])
            return
        
        address = context.args[0].strip()
        
        try:
            success = db_manager.unbind_address(chat_id, address)
            
            if success:
                success_msg = MESSAGE_TEMPLATES['unbind_success'].format(address=address)
                await update.message.reply_text(success_msg)
            else:
                await update.message.reply_text(MESSAGE_TEMPLATES['unbind_error_notfound'])
                
        except Exception as e:
            logger.error(f"解绑地址时出错: {e}")
            await update.message.reply_text(MESSAGE_TEMPLATES['unbind_error_format'])
    
    async def list_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """处理/list命令"""
        chat_id = update.effective_chat.id
        
        try:
            addresses = db_manager.get_user_addresses(chat_id)
            
            if not addresses:
                await update.message.reply_text(MESSAGE_TEMPLATES['list_empty'])
                return
            
            msg = MESSAGE_TEMPLATES['list_header']
            for i, (address, remark, created_at) in enumerate(addresses, 1):
                msg += f"{i}. {address}\n   备注：{remark}\n   绑定时间：{created_at}\n\n"
            
            await update.message.reply_text(msg)
            
        except Exception as e:
            logger.error(f"获取地址列表时出错: {e}")
            await update.message.reply_text("获取地址列表失败，请稍后重试。")
    
    def get_monitored_addresses(self):
        """获取所有监控地址"""
        return db_manager.get_all_monitored_addresses()
    
    def get_address_info(self, address):
        """获取地址信息"""
        return db_manager.get_address_subscribers(address)
    
    def is_transaction_processed(self, tx_hash):
        """检查交易是否已处理"""
        return db_manager.is_transaction_processed(tx_hash)
    
    def mark_transaction_processed(self, tx_hash):
        """标记交易为已处理"""
        db_manager.mark_transaction_processed(tx_hash)
    
    async def get_latest_transactions(self, address, contract_address=None):
        """获取最新交易"""
        try:
            if contract_address:
                # ERC20代币交易
                url = f"{POLYGON_CONFIG['ScanHost']}/api"
                params = {
                    'module': 'account',
                    'action': 'tokentx',
                    'contractaddress': contract_address,
                    'address': address,
                    'page': 1,
                    'offset': MAX_TRANSACTIONS_PER_REQUEST,
                    'startblock': 0,
                    'endblock': 99999999,
                    'sort': 'desc',
                    'apikey': POLYGON_CONFIG['ApiKey']
                }
            else:
                # ETH/MATIC交易
                url = f"{POLYGON_CONFIG['ScanHost']}/api"
                params = {
                    'module': 'account',
                    'action': 'txlist',
                    'address': address,
                    'page': 1,
                    'offset': MAX_TRANSACTIONS_PER_REQUEST,
                    'startblock': 0,
                    'endblock': 99999999,
                    'sort': 'desc',
                    'apikey': POLYGON_CONFIG['ApiKey']
                }
            
            response = requests.get(url, params=params, timeout=API_REQUEST_TIMEOUT)
            data = response.json()
            
            if data['status'] == '1':
                return data['result']
            else:
                logger.warning(f"API返回错误: {data.get('message', 'Unknown error')}")
                return []
                
        except Exception as e:
            logger.error(f"获取交易失败: {e}")
            return []
    
    def format_amount(self, amount, decimals):
        """格式化金额"""
        try:
            amount_float = float(amount) / (10 ** int(decimals))
            return f"{amount_float:,.6f}".rstrip('0').rstrip('.')
        except:
            return amount
    
    def format_transaction_message(self, tx, token_info, monitored_addresses):
        """格式化交易消息"""
        # 获取交易时间（北京时间）
        timestamp = int(tx['timeStamp'])
        beijing_tz = timezone(timedelta(hours=8))
        tx_time = datetime.fromtimestamp(timestamp, tz=beijing_tz)
        time_str = tx_time.strftime('%Y-%m-%d %H:%M:%S')
        
        # 判断交易类型
        from_addr = tx['from'].lower()
        to_addr = tx['to'].lower()
        
        # 获取地址备注
        from_remark = ""
        to_remark = ""
        
        for addr_info in monitored_addresses:
            if addr_info[0].lower() == from_addr:
                from_remark = f" ← {addr_info[1]}"
            if addr_info[0].lower() == to_addr:
                to_remark = f" ← {addr_info[1]}"
        
        # 格式化金额
        if token_info:
            amount = self.format_amount(tx['value'], tx['tokenDecimal'])
            token_symbol = token_info['Name']
        else:
            amount = self.format_amount(tx['value'], 18)  # POL默认18位小数
            token_symbol = "POL"
        
        # 判断是入账还是出账
        monitored_addr_list = [addr[0].lower() for addr in monitored_addresses]
        is_incoming = to_addr in monitored_addr_list
        is_outgoing = from_addr in monitored_addr_list
        
        if is_incoming and is_outgoing:
            transaction_type = "内部转账"
        elif is_incoming:
            transaction_type = "入账"
        elif is_outgoing:
            transaction_type = "出账"
        else:
            # 这种情况不应该发生，因为我们只监控相关地址的交易
            transaction_type = "未知"
        
        # 构建消息
        message = MESSAGE_TEMPLATES['transaction'].format(
            amount=amount,
            token=token_symbol,
            tx_type=transaction_type,
            from_addr=from_addr,
            from_remark=from_remark,
            to_addr=to_addr,
            to_remark=to_remark,
            time=time_str,
            hash=tx['hash']
        )
        
        return message
    
    async def monitor_transactions(self):
        """监控交易"""
        logger.info("开始监控交易...")
        
        while self.monitoring:
            try:
                # 获取所有监控地址
                addresses = self.get_monitored_addresses()
                
                if not addresses:
                    await asyncio.sleep(3)
                    continue
                
                # 获取所有地址信息（用于备注）
                all_address_info = []
                for addr in addresses:
                    info = self.get_address_info(addr)
                    all_address_info.extend([(addr, remark) for chat_id, remark in info])
                
                # 监控每个地址的交易
                for address in addresses:
                    # 监控ERC20代币交易
                    for token in POLYGON_CONFIG["ERC20"]:
                        transactions = await self.get_latest_transactions(address, token["ContractAddress"])
                        
                        for tx in transactions:
                            # 移除启动时间限制，处理所有未处理的交易
                            # if int(tx['timeStamp']) <= self.start_time:
                            #     continue
                            
                            # 检查是否已处理
                            if self.is_transaction_processed(tx['hash']):
                                continue
                            
                            # 标记为已处理
                            self.mark_transaction_processed(tx['hash'])
                            
                            # 发送通知
                            message = self.format_transaction_message(tx, token, all_address_info)
                            
                            # 发送给所有相关用户（包括发送方和接收方地址的绑定用户）
                            notified_users = set()
                            
                            # 通知发送方地址的绑定用户
                            from_addr_info = self.get_address_info(tx['from'])
                            for chat_id, remark in from_addr_info:
                                if chat_id not in notified_users:
                                    try:
                                        await self.application.bot.send_message(
                                            chat_id=chat_id,
                                            text=message
                                        )
                                        notified_users.add(chat_id)
                                    except Exception as e:
                                        logger.error(f"发送消息失败 {chat_id}: {e}")
                            
                            # 通知接收方地址的绑定用户
                            to_addr_info = self.get_address_info(tx['to'])
                            for chat_id, remark in to_addr_info:
                                if chat_id not in notified_users:
                                    try:
                                        await self.application.bot.send_message(
                                            chat_id=chat_id,
                                            text=message
                                        )
                                        notified_users.add(chat_id)
                                    except Exception as e:
                                        logger.error(f"发送消息失败 {chat_id}: {e}")
                    
                    # 监控POL交易
                    transactions = await self.get_latest_transactions(address)
                    
                    for tx in transactions:
                        # 移除启动时间限制，处理所有未处理的交易
                        # if int(tx['timeStamp']) <= self.start_time:
                        #     continue
                        
                        # 检查是否已处理
                        if self.is_transaction_processed(tx['hash']):
                            continue
                        
                        # 标记为已处理
                        self.mark_transaction_processed(tx['hash'])
                        
                        # 发送通知
                        message = self.format_transaction_message(tx, None, all_address_info)
                        
                        # 发送给所有相关用户（包括发送方和接收方地址的绑定用户）
                        notified_users = set()
                        
                        # 通知发送方地址的绑定用户
                        from_addr_info = self.get_address_info(tx['from'])
                        for chat_id, remark in from_addr_info:
                            if chat_id not in notified_users:
                                try:
                                    await self.application.bot.send_message(
                                        chat_id=chat_id,
                                        text=message
                                    )
                                    notified_users.add(chat_id)
                                except Exception as e:
                                    logger.error(f"发送消息失败 {chat_id}: {e}")
                        
                        # 通知接收方地址的绑定用户
                        to_addr_info = self.get_address_info(tx['to'])
                        for chat_id, remark in to_addr_info:
                            if chat_id not in notified_users:
                                try:
                                    await self.application.bot.send_message(
                                        chat_id=chat_id,
                                        text=message
                                    )
                                    notified_users.add(chat_id)
                                except Exception as e:
                                    logger.error(f"发送消息失败 {chat_id}: {e}")
                
                await asyncio.sleep(MONITOR_INTERVAL)  # 监控间隔
                
            except Exception as e:
                logger.error(f"监控过程中出错: {e}")
                await asyncio.sleep(MONITOR_INTERVAL)
    
    async def run(self):
        """运行机器人"""
        if not self.bot_token:
            logger.error("请设置TELEGRAM_BOT_TOKEN环境变量")
            return
        
        # 初始化数据库
        db_manager.init_database()
        
        # 创建应用
        self.application = Application.builder().token(self.bot_token).build()
        
        # 添加命令处理器
        self.application.add_handler(CommandHandler("start", self.start_command))
        self.application.add_handler(CommandHandler("bind", self.bind_command))
        self.application.add_handler(CommandHandler("unbind", self.unbind_command))
        self.application.add_handler(CommandHandler("list", self.list_command))
        
        # 启动机器人
        await self.application.initialize()
        await self.application.start()
        
        # 开始监控
        self.monitoring = True
        monitor_task = asyncio.create_task(self.monitor_transactions())
        
        logger.info("Polygon监控机器人已启动")
        
        try:
            # 开始轮询
            await self.application.updater.start_polling()
            
            # 等待监控任务
            await monitor_task
            
        except KeyboardInterrupt:
            logger.info("收到停止信号")
        finally:
            self.monitoring = False
            await self.application.stop()
            await self.application.shutdown()

if __name__ == "__main__":
    monitor = PolygonMonitor()
    asyncio.run(monitor.run())