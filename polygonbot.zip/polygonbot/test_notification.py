#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import asyncio
import sqlite3
from telegram import Bot
from config import TELEGRAM_BOT_TOKEN, MESSAGE_TEMPLATES
from datetime import datetime, timezone, timedelta

async def test_notification():
    """测试通知功能"""
    print("=" * 60)
    print("📱 测试Telegram通知功能")
    print("=" * 60)
    
    # 获取用户信息
    conn = sqlite3.connect('polygon.db')
    cursor = conn.cursor()
    cursor.execute('SELECT chat_id, username FROM users')
    users = cursor.fetchall()
    conn.close()
    
    if not users:
        print("❌ 没有找到注册用户")
        return
    
    # 创建bot实例
    bot = Bot(token=TELEGRAM_BOT_TOKEN)
    
    # 构造测试交易消息
    beijing_tz = timezone(timedelta(hours=8))
    current_time = datetime.now(tz=beijing_tz)
    time_str = current_time.strftime('%Y-%m-%d %H:%M:%S')
    
    # 模拟入账交易
    test_message_in = MESSAGE_TEMPLATES['transaction'].format(
        amount="0.100000",
        token="USDT",
        tx_type="入账",
        from_addr="0x1234567890abcdef1234567890abcdef12345678",
        from_remark=" ← 测试发送方",
        to_addr="0xd266034dd288bef58b265a7c16606508e3ae0996",
        to_remark=" ← 梦游主用",
        time=time_str,
        hash="0xtest1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef"
    )
    
    # 模拟出账交易
    test_message_out = MESSAGE_TEMPLATES['transaction'].format(
        amount="0.050000",
        token="USDT",
        tx_type="出账",
        from_addr="0xd266034dd288bef58b265a7c16606508e3ae0996",
        from_remark=" ← 梦游主用",
        to_addr="0x9876543210fedcba9876543210fedcba98765432",
        to_remark=" ← 测试接收方",
        time=time_str,
        hash="0xtest9876543210fedcba9876543210fedcba9876543210fedcba9876543210fedcba"
    )
    
    # 发送测试消息
    for chat_id, username in users:
        print(f"📤 向用户 {username} (ID: {chat_id}) 发送测试通知...")
        
        try:
            # 发送入账通知
            await bot.send_message(
                chat_id=chat_id,
                text=f"🧪 **测试通知 - 入账交易**\n\n{test_message_in}"
            )
            print("  ✅ 入账通知发送成功")
            
            # 等待1秒
            await asyncio.sleep(1)
            
            # 发送出账通知
            await bot.send_message(
                chat_id=chat_id,
                text=f"🧪 **测试通知 - 出账交易**\n\n{test_message_out}"
            )
            print("  ✅ 出账通知发送成功")
            
            # 发送说明消息
            await asyncio.sleep(1)
            explanation = (
                "📋 **测试说明**\n\n"
                "刚才发送的两条消息演示了入账和出账通知的格式。\n\n"
                "如果您能看到这两条测试消息，说明通知系统工作正常。\n\n"
                "实际监控中，只有在绑定地址发生新交易时才会收到通知。\n\n"
                "当前监控状态：\n"
                "• 只监控程序启动后的新交易\n"
                "• 已处理的交易不会重复通知\n"
                "• 同时监控入账和出账交易"
            )
            
            await bot.send_message(
                chat_id=chat_id,
                text=explanation
            )
            print("  ✅ 说明消息发送成功")
            
        except Exception as e:
            print(f"  ❌ 发送失败: {e}")
    
    print("\n🎉 测试完成！")
    print("\n💡 如果您在Telegram中收到了测试消息，说明通知系统工作正常。")
    print("   如果没有收到，请检查：")
    print("   1. Telegram bot token是否正确")
    print("   2. 是否已经与bot进行过对话（发送过/start命令）")
    print("   3. 网络连接是否正常")

if __name__ == "__main__":
    asyncio.run(test_notification())